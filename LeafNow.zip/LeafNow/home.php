<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Leaf Now</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel= "stylesheet" href="spy.css"/>
</head>
<body background="C:\xampp\htdocs\Internship\images\plant4.jpg">
  <div class="container"> 
    <nav role="navigation" >  

    <ul id="menu">

    <li><a href="register.html" target="_blank">Sign Up</a></li> 
    <li><a href="login1.html" target="_blank">Login</a></li>
    <div id="abc">
    </div>
    
</ul>


    <div class="quote">
   
    <blockquote>
        <p>"A tree against the sky possesses the same interest, the same character, the same expression as the figure of a human."
    </p>
        </blockquote>
    <small class="name">- Georges Rouault</small>
</div>
</div>
</body>
</html>