
var products = {
    123: {
      name : "Hybrid Guava Seeds",
      img : "seed3.jpg",
      price : 250
    },
    124: {
      name : "Sunflower Seeds",
      img : "seed2.jpg",
      price : 350
    },
    125: {
      name : "Sedeveria Green Rose - Plant",
      img : "pt1.jpg",
      price : 450
    },
    126: {
      name : "Peace Lily, Spathiphyllum - Plant",
      img : "pt2.jpg",
      price : 430
    },
  };